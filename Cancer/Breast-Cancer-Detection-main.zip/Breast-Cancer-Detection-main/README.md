# Breast-Cancer-Detection

main.ipynb is the main file, starting by running main.ipynb
